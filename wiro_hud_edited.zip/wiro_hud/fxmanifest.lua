fx_version "adamant" -- bodacious

game "gta5"

client_script {
    'client.lua',
    "conifg.lua"
}

ui_page('UI/index.html')

files {
    "UI/index.html",
    "UI/style.css",
    "UI/index.js",
    "UI/JuhlBold.ttf",
}