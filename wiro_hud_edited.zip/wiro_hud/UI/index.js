$(document).ready(function(){

    window.addEventListener('message', function(event) {
        var item = event.data;
        if (item.type === "arac") {
            if (item.bool) {
                aracici()
            }
            else {
                aracdisi()
            }
        }
        else if (item.type === "updateStatusHudmain") {
            $("#yükselcan").attr("height", String(38 - Math.floor(item.health)))
            $("#yükselzirh").attr("height", String(38 - Math.floor(item.armour)))
        }
        else if (item.type === "updateStatusHudOthers") {
            $("#yükselyemek").attr("height", String(38 - Math.floor(item.hunger)))
            $("#yükselsu").attr("height", String(38 - Math.floor(item.thirst)))
        }
        else if (item.type === "kemer") {
            if(item.takili) {
                $("#kemeracik").hide();
                $("#kemertakili").show();
            }
            else {
                $("#kemeracik").show();
                $("#kemertakili").hide();
            }
        }
        else if (item.type === "aracOthers") {
            $(".hiz").text(String(Math.floor(item.speed)))
            $("#yükselbenzin").attr("height", String(38 - Math.floor(item.fuel)))
            var hizint = 255 - Math.floor(item.speed)
            if (hizint < 0) hizint = 0;
            $(".vehicle-holder").css("border-color", "rgba(20, 19, 23, 0.5) rgba(20, 19, 23, 0.5) rgb(" + String(255 - hizint) + ", 40, 40) rgb("+ String(255 - hizint) + ", 40, 40)")
            if (item.engine) {
                $("#motorpath").addClass("yesilparlama")
            }
            else {
                $("#motorpath").removeClass("yesilparlama")
            }
            if (item.light === 1) {
                $(".farr").addClass("sariparlama")
            }
            else {
                $(".farr").removeClass("sariparlama")   
            }
        }
        else if (item.type === "sinyal") {
            if (item.index === "right") {
                $(".sagokk").addClass("sariparlama")
                $(".solokk").removeClass("sariparlama")
            }
            else if (item.index === "left") {
                $(".sagokk").removeClass("sariparlama")
                $(".solokk").addClass("sariparlama")
            }
            else if (item.index === "both") {
                $(".sagokk").addClass("sariparlama")
                $(".solokk").addClass("sariparlama")
            }
            else {
                $(".sagokk").removeClass("sariparlama")
                $(".solokk").removeClass("sariparlama")
            }
        }
    })

    function aracici() {
        $(".vehicle-holder").fadeIn(500);
        // CAN
        $( "#can" ).animate({
            right: "93.5%",
            bottom: "26.9%"
          }, 1200, function() {
            $("#can").addClass("carcan")
        });
        // CAN
        // ZIRH
        $( "#zirh" ).animate({
            right: "95.5%",
            bottom: "21.4%"
          }, 1200, function() {
            $("#zirh").addClass("carzirh")
        });
        // ZIRH
        // YEMEK
        $( "#yemek" ).animate({
            right: "96.2%",
            bottom: "15.2%"
            }, 1200, function() {
            $("#yemek").addClass("caryemek")
        });
        // YEMEK
        // SU
        $( "#su" ).animate({
            right: "95.5%",
            bottom: "8.9%"
            }, 1200, function() {
            $("#su").addClass("carsu")
        });
        // SU
        // MİK
        $( "#mik" ).animate({
            right: "93.5%",
            bottom: "3.7%"
            }, 1200, function() {
            $("#mik").addClass("carsmik")
        });
        // MİK
    }

    function aracdisi() {
        $(".vehicle-holder").fadeOut(500);
        // CAN
        $( "#can" ).animate({
            right: "96.8%",
            bottom: "25%"
          }, 900, function() {
            $("#can").removeClass("carcan")
        });
        // CAN
        // ZIRH
        $( "#zirh" ).animate({
            right: "96.8%",
            bottom: "19%"
          }, 900, function() {
            $("#zirh").removeClass("carzirh")
        });
        // ZIRH
        // YEMEK
        $( "#yemek" ).animate({
            right: "96.8%",
            bottom: "13%"
            }, 900, function() {
            $("#yemek").removeClass("caryemek")
        });
        // YEMEK
        // SU
        $( "#su" ).animate({
            right: "96.8%",
            bottom: "7%"
            }, 900, function() {
            $("#su").removeClass("carsu")
        });
        // SU
        // MİK
        $( "#mik" ).animate({
            right: "96.8%",
            bottom: "1%"
            }, 900, function() {
            $("#mik").removeClass("carsmik")
        });
        // MİK
        
    }
    

});